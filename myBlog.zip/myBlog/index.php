<!DOCTYPE html>
<html>
<head>
  <title>myBlog</title>
</head>
<link rel="stylesheet" href="style.css">
<body>
   <!--шапка-->
  <div class="header">
<div id="logo">
<img src="./img/logo.png">
</div>
<div id="menu">
  <p>Главная</p>
  <p>Посты</p>
</div>
<div id="forms">
<input type="button" id="vhod" value="вход">
<input type="button" id="reg" value="регистрация">
<input type="button" id="exit" value="выход">
</div>
  </div>
  <!--только у нас-->
  <div class="best">
  <div id="img">
    <img src="./img/ph.png">
    </div>

    <div id="txt">
    <h1>лучшие</h1>
    <h1>подборки</h1>
    <h1>только</h1>
    <h1>у нас</h1>
    </div>

    <div id="img">
    <img src="./img/ph.png">
    </div>

  </div>
  <!--посты-->
  <h1 style="text-align: center">НОВИНКИ 2024 ГОДА</h1>
  <div class="posts" id="posts">
        <div class="container">
            <h2>Книжные новинки и интересные книги</h2>
            <div class=" posts-cards">
                <?php
 
                // Заполняю список постов
                $con= new mysqli("localhost", "root", "", "borovinskikhBlog");

                $query = "SELECT post.*, Book.Title AS BookTitle FROM post LEFT JOIN Book ON Post.Book_ID = Book.Book_ID LEFT JOIN Author ON Book.Author_ID = Author.Author_ID";
                $result = mysqli_query($con, $query);

                while ($row = mysqli_fetch_assoc($result)) {
                    echo '
                    <div class="col-sm-5  mb-3 mb-sm-0 col-lg-3">
                        <div class="card">
                            <div class="card-body">
                               <div class="card-img">  <img src="media/images/posts/' . $row['photo'] . '"></img></div>
                                <h4>' . $row['Title'] . '</h4>
                                <p class="card-text truncate">' . $row['Text'] . '</p>
                                
                                <div class="d-block"> 
                                    <div class="d-flex justify-content-between">
                                        <p class="ligth">' . $row['BookTitle'] . '</p>
                                        <p class="ligth"> ' . $row['AuthorName'] . '</p>

                                       <!--<p class="ligth">' . $row['Date'] . '</p>-->
                                    </div>
                                </div>
                                <a href="post.php?id=' . $row['Post_ID'] . '" class="btn btn-primary">Читать</a>   ';

                    echo '
                                 <form method="get" action="post.php">
                                    <input type="text" name="Post_ID" value=' . $row['Post_ID']  . ' class="hidden">
                                </form>
                            </div>
                        </div>
                    </div>
                    ';
                }
                ?>

            </div>
        </div>
    </div>
  <!--подвал-->
  <div class="footer">
    <div id="txt">
    <p>©️2024<p>
    <p>все права защищены<p>
    </div>
  </div>
</body>
</html>
<?php

?>