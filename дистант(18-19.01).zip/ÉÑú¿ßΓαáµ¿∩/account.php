<?php
session_start();
$id = $_SESSION['id'];
$conn = new mysqli("localhost", "root", "", "test");
$query = "SELECT * FROM users WHERE id='$id'";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);
?>
<form action="" method="POST">
    <input name="name" value="<?= $user['name'] ?>" placeholder="имя">
    <br>
    <br>
    <input name="surname" value="<?= $user['surname'] ?>" placeholder="фамилия">
    <input type="submit" name="submit">
</form>
<?php
if (!empty($_POST['submit'])) {
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $query = "UPDATE users SET name='$name', surname='$surname' WHERE id=$id";
    mysqli_query($conn, $query);
    header("Location: login.php"); 
}
?>
