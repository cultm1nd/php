<form action="" method="POST">
    <input type="password" name="password" placeholder="пароль">
    <input type="submit" name="submit">
</form>
<?php
session_start();
$link = new mysqli("localhost", "root", "", "test");
$id = $_SESSION['id'];
$query = "SELECT * FROM users WHERE id='$id'";
$result = mysqli_query($link, $query);
$user = mysqli_fetch_assoc($result);
$hash = $user['password'];
if(!empty($_POST['submit']))
{
    if (password_verify($_POST['password'], $hash)) {
        $query = "DELETE FROM users WHERE id='$id'";
        mysqli_query($link, $query);
        $_SESSION['auth']=false;
        header("Location: login.php"); 
    } 
    else 
    {
        echo "пароль введен неверно";
    }
}
?>
