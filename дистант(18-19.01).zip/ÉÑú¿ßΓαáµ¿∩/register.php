<form action="" method="POST">
    <h1>регистрация</h1>
    <input name="login" required="" placeholder="Логин">
    <br>
    <br>
    <input name="password" required="" type="password" placeholder="Пароль">
    <br>
    <br>
    <input type="password" required="" placeholder="Подтверждение пароля" name="confirm">
    <br>
    <br>
    <input type="submit">
</form>
<?php
session_start();
if (!empty($_POST['login']) and !empty($_POST['password']) and !empty($_POST['confirm'])) 
{ 
    $link = new mysqli("localhost", "root", "", "test"); 
    $login = $_POST['login'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $query = "SELECT * FROM users WHERE login='$login'"; 
    $result = mysqli_query($link,$query);
    if ($_POST['password'] == $_POST['confirm']) 
    {
        if(mysqli_num_rows($result)>0) 
        { 
            echo "<p id='text'>пользователь с таким логином уже существует</p>"; 
        } 
        else 
        { 
            $insertquery = "INSERT INTO users SET login='$login', password='$password', status_id='1'"; 
            mysqli_query($link, $insertquery);
            $_SESSION['auth'] = true;
            $id = mysqli_insert_id($link);
            $_SESSION['id'] = $id;
            header("Location: login.php"); 
        }
    } 
    else 
    {
        echo '<p id="text">пароли не совпадают</p>';
    } 
    
}
?>
