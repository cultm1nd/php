<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>Введение в Фреймворк Laravel</title>
</head>
<body>

	<header>
		<p>Шапка сайта</p>
	</header>

	<body>
		<h1>{{ $name }}</h1>
	</body>
	
	<footer>
		<p>Подвал сайта</p>
	</footer>

</body>
</html>