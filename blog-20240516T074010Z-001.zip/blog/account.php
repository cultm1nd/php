<?php
    include "pages/header.php";
    ?>
<?php

$conn = mysqli_connect("localhost", "root", "", "Nikiforova");
session_start();
$id = $_SESSION['id'];
$sql = "SELECT * FROM blog_users where id='$id'";
 if($result = $conn->query($sql)){
    $rowsCount = $result->num_rows; 
    echo "<p>Информация о пользователе</p>";
    echo "<table border='1'><tr><th>Имя пользователя</th><th>Фамилия</th><th>Отчество</th><th>Номер телефона</th><th>Почта</th></tr>";
    foreach($result as $row){
        echo "<tr>";
            echo "<td>" . $row["name"] . "</td>";
            echo "<td>" . $row["surname"] . "</td>";
            echo "<td>" . $row["lastname"] . "</td>";
            echo "<td>" . $row["phone_number"] . "</td>";
            echo "<td>".$row["email"]."</td>";
        echo "</tr>";
    }
    echo "</table>";}
$sql = "SELECT * FROM comment where id_blog_users='$id' and id_status='1' ";
if($result = $conn->query($sql)){ 
    echo "<p>Комменты</p>";
    while($row =$result->fetch_assoc()){
      echo '<p> '.$row['text'] ."</p>";
    }
} else{
    echo "Ошибка: " . $conn->error;
}

?>
