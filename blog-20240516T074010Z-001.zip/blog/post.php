<?php
    include "pages/header.php";
?>
<?php 
$conn = new mysqli("localhost", "root", "", "Nikiforova");
if($conn->connect_error){
    die("Ошибка: " . $conn->connect_error);
}
session_start();

?>
<!DOCTYPE html>
<html>
<head>
<title></title>
<meta charset="utf-8" />
<style>
    p
    {
        font-size: 18px;
    }
    .post img 
    {
        width: 500px;
        height: 300px;
    }
</style>
</head>
<body>
<?php
if($_SERVER["REQUEST_METHOD"] === "GET" && isset($_GET["id_post"]))
{
    $id_post = $conn->real_escape_string($_GET["id_post"]);
    $sql = "SELECT * FROM posts WHERE id = '$id_post'";
    if($result = $conn->query($sql)){ 
        while($row =$result->fetch_assoc()){
        echo "<div class='post'>";
          echo '<h2> '.$row['name_post'] ."</h2>";
          echo '<img src="'.$row['img'].'">';
          echo '<p>'.$row['text_post'].'</p>';
          echo "</div>";
        }
    } else{
        echo "Ошибка: " . $conn->error;
    }
}
$id=$_SESSION['id'];
?>
<div class="write">
    <form action="">
        <textarea name="comm" id="" cols="30" rows="10"></textarea>
        <input type="submit">
    </form>
<?php
    if (!empty($_POST['comm'])) {
        $name = $_POST['comm'];
        $query = "INSERT INTO comment SET id_blog_users='$id, text='$name', id_status='3', id_posts='$id_post'";
        mysqli_query($conn, $query);
        echo 'Успешно!';
        }
 ?>
</div>
<div class="comments">
<?php
$sql = "SELECT comment.*, blog_users.login as name from comment LEFT JOIN blog_users ON comment.id_blog_users=blog_users.id where id_status='1' and id_posts='$id_post' ";
if($result = $conn->query($sql)){ 
    while($row =$result->fetch_assoc()){
        echo '<div class="com">';
        echo '<p>'.$row['name'].'</p>';
        echo '<p> '.$row['text'] ."</p>";
        echo '</div>';
    }
} else{
    echo "Ошибка: " . $conn->error;
}
?>
</div>
<?php
    include "pages/footer.php";
?>
</body>
</html>