-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Фев 05 2024 г., 15:38
-- Версия сервера: 8.0.30
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `Nikiforova`
--

-- --------------------------------------------------------

--
-- Структура таблицы `comment`
--

CREATE TABLE `comment` (
  `id` int NOT NULL,
  `id_blog_users` int NOT NULL,
  `text` varchar(150) NOT NULL,
  `id_status` int NOT NULL,
  `id_posts` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `comment`
--

INSERT INTO `comment` (`id`, `id_blog_users`, `text`, `id_status`, `id_posts`) VALUES
(5, 3, 'Слов нет - одни эмоции. Душа болит, а сердце плачет.....Радует, что ребята будут в одном учебном центре  ', 1, 1),
(6, 2, 'Юнги дольше всех ждать...\r\nА Джин уже вот-вот вернется! Как быстро год уже пролетел!', 1, 1),
(7, 4, 'ФУ наконец-то они уже уйдут а то всех задолбали уже', 2, 1),
(8, 3, 'Готовим почки, чтобы попасть на концерт!!\r\n', 1, 2),
(9, 2, 'Спасибо, отец\r\n', 1, 2),
(10, 2, 'В Сингапур или Бангкок вполне реально прилететь, осталось накопить деньги на концерт\r\n', 1, 2),
(11, 3, 'Скорее бы они все вернулись из армии\r\n', 1, 3),
(12, 2, 'Ким Тэхен, мы в тебя верим. Порви их всех!!\r\n', 1, 3),
(13, 4, 'Прикиньте каким шкафом он вернется из армии.\r\n', 1, 3),
(14, 3, 'Я не могу забыть “Любовь побеждает все”', 1, 4),
(15, 4, 'Я знаю, что у них есть продолжение клипа с этой сюжетной линией, пожалуйста, выпустите его', 1, 4),
(16, 2, 'Они так хорошо смотрятся вместе', 1, 4);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_blog_users` (`id_blog_users`,`id_status`),
  ADD KEY `id_status` (`id_status`),
  ADD KEY `id_post` (`id_posts`),
  ADD KEY `id_posts` (`id_posts`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `comment`
--
ALTER TABLE `comment`
  ADD CONSTRAINT `comment_ibfk_1` FOREIGN KEY (`id_status`) REFERENCES `status` (`id`),
  ADD CONSTRAINT `comment_ibfk_2` FOREIGN KEY (`id_blog_users`) REFERENCES `blog_users` (`id`),
  ADD CONSTRAINT `comment_ibfk_3` FOREIGN KEY (`id_posts`) REFERENCES `posts` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
