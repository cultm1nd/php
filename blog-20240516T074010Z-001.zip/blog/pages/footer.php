<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
       footer
        {
            display: flex;
            justify-content: end;
            font-size: 15px;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <footer>
       <p>Разработчик: Никифорова Алена</p> 
    </footer>
</body>
</html>