<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <style>
        header{
            width: 100%;
            display: flex;
            justify-content: space-between;
        }
        header img
        {
            width: 100px;
            margin-left:10px ;
            margin-top: -15px;
        }
        header a{
            width: 100px;
            height: 30px;
            margin-top: 20px;
            border: none;
            border-radius: 5px;
            background-color: #B56AFF;
            font-size: 20px;
            font-weight: 600;
            text-decoration: none;
            color: black;
            display: flex;
            justify-content: center;
            padding-top: 5px;
            margin-left: 9px;
        }
        header div
        {
            display: flex;

        }
    </style>
</head>
<body>
    <header>
       <img src="img/whale.png" alt="">
       <div>
        <a href="entrance.php">Вход</a> <a href="exit.php">Выход</a>
       </div>
    
    </header>
    
</body>
</html>
