<?php
    include "pages/header.php";
    ?>
<?php 
$conn = new mysqli("localhost", "root", "", "Nikiforova");
if($conn->connect_error){
    die("Ошибка: " . $conn->connect_error);
}
?>
<!DOCTYPE html>
<html>
<head>
<title></title>
<meta charset="utf-8" />
</head>
<body>
<?php
if($_SERVER["REQUEST_METHOD"] === "GET" && isset($_GET["id"]))
{
    $id = $conn->real_escape_string($_GET["id"]);
    $sql = "SELECT * FROM comment WHERE id = '$id'";
    if($result = $conn->query($sql)){
        if($result->num_rows > 0){
            foreach($result as $row){
                $id=$row['id'];
                $status= $row["id_status"];
            }
            echo "<h3>Редактировать статус</h3>
                <form method='post'>
                <input type='hidden' name='id' value='$id'>
                    <p>Статус:
                    <input type='text' name='status' value='$status' /></p>
                    <input type='submit' value='Сохранить'>
            </form>";
        }
        else{
            echo "<div>Коммент не найден</div>";
        }
        $result->free();
    } else{
        echo "Ошибка: " . $conn->error;
    }
}
else if (isset($_POST["status"])) {
    $status= $conn->real_escape_string($_POST["status"]);
    $id=$conn->real_escape_string($_POST["id"]);
    $sql = "UPDATE comment SET id_status = '$status' where id='$id'";
    if($result = $conn->query($sql)){
        echo "fggf";
    } else{
        echo "Ошибка: " . $conn->error;
    }
}
else{
    echo "Некорректные данные";
}
$conn->close();
?>
<?php
    include "pages/footer.php";
    ?>
</body>
</html>