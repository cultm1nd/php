<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php 
     $conn = new mysqli("localhost", "root", "", "Nikiforova"); 
     if($conn->connect_error){
         die("Ошибка: " . $conn->connect_error);
     }
     session_start();
    ?>
    <style>
        .con
        {
            width: 100%;
            display: flex;
            justify-content: center;
            margin-top: 30px;
        }
        form
        {
            background-color: #CA95FF;
            width: 400px;
            height: 500px;
            border-radius: 10px;
        }
        form input
        {
            width: 350px;
            margin-left: 20px;
            margin-top: 20px;
            font-size: 20px;
            border-radius: 5px;
            border: none;
        }
    </style>
</head>
<body>
    <?php
    include "pages/header.php";
    ?>
    <div class="con">
    <form action="" method="POST">
    <input name="login" placeholder="Логин">
    <input name="password" type="password" placeholder="Пароль">
    <input name="confirm" type="password" placeholder="Подтверждение пароля">
    <input name="name" type="name" placeholder="Имя">
    <input name="surname" type="surname" placeholder="Фамилия">
    <input name="lastname" type="lastname" placeholder="Отчество">
    <input name="phone" type="phonenumber" placeholder="Номер телефона">
    <input name="email" type="email" placeholder="Эл. почта">
    <input name="status" type="status" placeholder="Статус аккаунта">
    <input type="submit">
    </form></div>
    <?php 
    if (!empty($_POST['login']) and !empty($_POST['password']) and !empty($_POST['confirm']) ) {
       if (($_POST['password'] == $_POST['confirm']) ) {
            $login = $_POST['login'];
            $password = $_POST['password'];
            $name = $_POST['name'];
            $surname = $_POST['surname'];
            $lastname = $_POST['lastname'];
            $phone = $_POST['phone'];
            $email = $_POST['email'];
            $status=$_POST['status'];
            if ($status=='admin')
            {
              $status = 1;  
            }
            else if ($status=='user')
            {
                $status= 2;
            }
            $query = "SELECT * FROM blog_users WHERE login='$login'";
            $user = mysqli_fetch_assoc(mysqli_query($conn, $query));
            if (empty($user)) {
                $query = "INSERT INTO blog_users SET login='$login', password='$password', name='$name', surname='$surname', lastname='$lastname', phone_number='$phone', email='$email', id_status_users='$status'";
                mysqli_query($conn, $query);
                $_SESSION['auth'] = true;
                $id = mysqli_insert_id($conn);
                $_SESSION['id'] = $id;
                echo 'Успешно!';
            } else {
            echo 'Логин занят';
            }
        } else {
            echo 'Пароли не совпадают';
        }
    }
    ?>
    <?php
    include "pages/footer.php";
    ?>
</body>
</html>