<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php 
     $conn = mysqli_connect("localhost", "root", "", "Nikiforova"); 
     if($conn->connect_error){
         die("Ошибка: " . $conn->connect_error);
     }
     session_start();
    ?>
    <style>
        .con
        {
            width: 100%;
            display: flex;
            justify-content: center;
            margin-top: 30px;
        }
        form
        {
            background-color: #CA95FF;
            width: 400px;
            height: 190px;
            border-radius: 10px;
        }
        form input
        {
            width: 350px;
            margin-left: 20px;
            margin-top: 20px;
            font-size: 20px;
            border-radius: 5px;
            border: none;
        }
        .regg{
            background-color: whitesmoke;
            border-radius: 5px;
        }
        .regg 
        {
            position: relative;
            top: 15px;
            text-decoration: none;
            color: black; 
            margin-left: 20px;
            font-size: 20px;
            width: 400px;
            height: 20px;
        }
    </style>
</head>
<body>
    <?php
    include "pages/header.php";
    ?>
<div class="con">
    <form action="" method="POST">
    <input name="login" placeholder="Логин">
    <input name="password" type="password" placeholder="Пароль">
    <input type="submit"> 
    <a class="regg" href="reg.php">Зарегистрироваться</a>
    </form>
</div>
    <?php 
    if (empty($_SESSION['auth'])) {
        echo 'Пользователь не авторизирован';
    } else {
        echo 'Пользователь авторизирован<br>';
        echo '<a href="admin.php">Страничка админа</a><br>';
        echo '<a href="account.php">Личный кабинет</a><br>';
        echo '<a href="main.php">Главная</a>';
    }
    ?>
    <?php 
    if (!empty($_POST['login']) and !empty($_POST['password']) ) {
            $login = $_POST['login'];
            $password = $_POST['password'];
            $query = "SELECT blog_users.*, status_users.name_status as status FROM blog_users LEFT JOIN status_users ON blog_users.id_status_users=status_users.id WHERE login='$login'";
            $result = mysqli_query($conn, $query);
            $user = mysqli_fetch_assoc($result);
            if (!empty($user)) {
                $_SESSION['auth'] = true;
                $_SESSION['status'] = $user['status'];
                $_SESSION['id'] = $user['id'];
                echo "<meta http-equiv='refresh' content='0'>";
                } else {
                echo 'Неправильный пароль!';
                }
            } else {
                echo 'Пользователя с таким логином нет';
            }
    ?>
    <?php
    include "pages/footer.php";
    ?>
</body>
</html>