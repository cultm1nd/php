
<?php
session_start();
$conn = mysqli_connect("localhost", "root", "", "Nikiforova");
$status=$_SESSION['status'];
if (($status=='1' or $status=='admin') and $_SESSION['auth']==true)
{
?>
<?php
    include "pages/header.php";
    ?>


<form action="" method="post">
<input name="name" value="Название поста"><br><br>
<input type="text" value="Картинка" name='img'><br><br>
<textarea value='Текст поста' name='text'></textarea><br><br>
<input type="submit" name="submit">
</form>

<?php
if (!empty($_POST['name']) and !empty($_POST['img']) and !empty($_POST['text']) ) {
         $name = $_POST['name'];
         $img = $_POST['img'];
         $text= $_POST['text'];
         $query = "SELECT * FROM posts WHERE name_post='$name'";
         $user = mysqli_fetch_assoc(mysqli_query($conn, $query));
         if (empty($user)) {
             $query = "INSERT INTO posts SET name_post='$name', img='$img', text_post='$text'";
             mysqli_query($conn, $query);
             echo 'Успешно!';
         } else {
         echo 'Пост с таким именем уже существует';
         }
 }
 $sql = "SELECT comment.*,blog_users.login as name from comment LEFT JOIN blog_users ON comment.id_blog_users=blog_users.id";
 if($result = $conn->query($sql)){
    $rowsCount = $result->num_rows; 
    echo "<p> Комменты пользователей</p>";
    echo "<table border='1'><tr><th>Имя пользователя</th><th>Коммент</th><th>Статус</th><th>Редактировать</th><th>Удалить</th></tr>";
    foreach($result as $row){
        echo "<tr>";
            echo "<td>" . $row["name"] . "</td>";
            echo "<td>" . $row["text"] . "</td>";
            echo "<td>" . $row["id_status"] . "</td>";
            echo "<td><form action='update.php' method='get'>
            <input type='hidden' name='id' value='" . $row["id"] . "' />
            <input type='submit' value='Редактировать' class='button'>
    </form></td>";
            echo "<td><form action='delete_com.php' method='post'>
                        <input type='hidden' name='id' value='" . $row["id"] . "' />
                        <input type='submit' value='Удалить'>
                </form></td>";
        echo "</tr>";
    }
    echo "</table>";}
?>

<?php
    include "pages/footer.php";
    ?>
<? }
else {
    echo 'Вы не админ';
}
?>
