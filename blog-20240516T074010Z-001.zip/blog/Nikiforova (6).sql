-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Фев 05 2024 г., 15:40
-- Версия сервера: 8.0.30
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `Nikiforova`
--

-- --------------------------------------------------------

--
-- Структура таблицы `articles`
--

CREATE TABLE `articles` (
  `id_art` int NOT NULL,
  `name` varchar(50) NOT NULL,
  `text` longtext NOT NULL,
  `avtor` varchar(50) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `articles`
--

INSERT INTO `articles` (`id_art`, `name`, `text`, `avtor`, `date`) VALUES
(3, 'потп', 'арпоьтмрпьотм мрпьм рп ь', 'пота', '2023-12-06');

-- --------------------------------------------------------

--
-- Структура таблицы `blog_users`
--

CREATE TABLE `blog_users` (
  `id` int NOT NULL,
  `login` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` int NOT NULL,
  `name` varchar(30) NOT NULL,
  `surname` varchar(30) NOT NULL,
  `lastname` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `phone_number` bigint DEFAULT NULL,
  `email` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `id_status_users` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `blog_users`
--

INSERT INTO `blog_users` (`id`, `login`, `password`, `name`, `surname`, `lastname`, `phone_number`, `email`, `id_status_users`) VALUES
(1, 'big_admin', 696969, 'Алена', 'Никифорова', 'Андреевна', 89563457887, 'nikiforovaalena329@gmail.com', 1),
(2, 'yoongiswife', 9031993, 'Маша', 'Иванова', 'Ивановна', 89563214558, 'yooni2025@gmail.com', 2),
(3, 'namjin77', 1234567, 'Иван', 'Иванов', 'Иванович', 89532456723, 'jjin30@gmail.com', 2),
(4, 'popa', 123, 'Маша', 'Иванова', 'Ивановна', 8964356465, 'fdgdh@mail.com', 2);

-- --------------------------------------------------------

--
-- Структура таблицы `catalog`
--

CREATE TABLE `catalog` (
  `id_company` int NOT NULL,
  `name_company` varchar(50) NOT NULL,
  `tovar` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `catalog`
--

INSERT INTO `catalog` (`id_company`, `name_company`, `tovar`) VALUES
(2, 'samovar', 'posuda');

-- --------------------------------------------------------

--
-- Структура таблицы `category`
--

CREATE TABLE `category` (
  `id` int NOT NULL,
  `name_category` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `category`
--

INSERT INTO `category` (`id`, `name_category`) VALUES
(1, 'Фильм'),
(2, 'Книга'),
(3, 'Мультфильм');

-- --------------------------------------------------------

--
-- Структура таблицы `chek`
--

CREATE TABLE `chek` (
  `id chek` int NOT NULL,
  `obsh stoimost` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `chek`
--

INSERT INTO `chek` (`id chek`, `obsh stoimost`) VALUES
(1, 5000),
(2, 2500);

-- --------------------------------------------------------

--
-- Структура таблицы `client`
--

CREATE TABLE `client` (
  `id client` int NOT NULL,
  `FIO` varchar(100) NOT NULL,
  `phone` bigint NOT NULL,
  `id menu` int NOT NULL,
  `id chek` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `client`
--

INSERT INTO `client` (`id client`, `FIO`, `phone`, `id menu`, `id chek`) VALUES
(1, 'Петрова Маша Петровна', 895634657883, 1, 2),
(2, 'Пупкин Вася Васильевич', 89647273645, 1, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `comment`
--

CREATE TABLE `comment` (
  `id` int NOT NULL,
  `id_blog_users` int NOT NULL,
  `text` varchar(150) NOT NULL,
  `id_status` int NOT NULL,
  `id_posts` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `comment`
--

INSERT INTO `comment` (`id`, `id_blog_users`, `text`, `id_status`, `id_posts`) VALUES
(5, 3, 'Слов нет - одни эмоции. Душа болит, а сердце плачет.....Радует, что ребята будут в одном учебном центре  ', 1, 1),
(6, 2, 'Юнги дольше всех ждать...\r\nА Джин уже вот-вот вернется! Как быстро год уже пролетел!', 1, 1),
(7, 4, 'ФУ наконец-то они уже уйдут а то всех задолбали уже', 2, 1),
(8, 3, 'Готовим почки, чтобы попасть на концерт!!\r\n', 1, 2),
(9, 2, 'Спасибо, отец\r\n', 1, 2),
(10, 2, 'В Сингапур или Бангкок вполне реально прилететь, осталось накопить деньги на концерт\r\n', 1, 2),
(11, 3, 'Скорее бы они все вернулись из армии\r\n', 1, 3),
(12, 2, 'Ким Тэхен, мы в тебя верим. Порви их всех!!\r\n', 1, 3),
(13, 4, 'Прикиньте каким шкафом он вернется из армии.\r\n', 1, 3),
(14, 3, 'Я не могу забыть “Любовь побеждает все”', 1, 4),
(15, 4, 'Я знаю, что у них есть продолжение клипа с этой сюжетной линией, пожалуйста, выпустите его', 1, 4),
(16, 2, 'Они так хорошо смотрятся вместе', 1, 4);

-- --------------------------------------------------------

--
-- Структура таблицы `Dop uslugi`
--

CREATE TABLE `Dop uslugi` (
  `id dop uslugi` int NOT NULL,
  `name uslugi` varchar(100) NOT NULL,
  `time` time NOT NULL,
  `stoimost` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `Dop uslugi`
--

INSERT INTO `Dop uslugi` (`id dop uslugi`, `name uslugi`, `time`, `stoimost`) VALUES
(1, 'Караоке', '02:30:00', 2000),
(3, 'Оркестр', '01:30:00', 5000),
(4, 'Клоун', '01:00:00', 3000);

-- --------------------------------------------------------

--
-- Структура таблицы `menu`
--

CREATE TABLE `menu` (
  `id menu` int NOT NULL,
  `id dish` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `menu`
--

INSERT INTO `menu` (`id menu`, `id dish`) VALUES
(1, 1),
(2, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `notes`
--

CREATE TABLE `notes` (
  `id_notes` int NOT NULL,
  `name_notes` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `id_category` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `notes`
--

INSERT INTO `notes` (`id_notes`, `name_notes`, `id_category`) VALUES
(1, 'Колобо', 2),
(2, 'Золушка', 2),
(10, 'Золушка', 3),
(12, 'Русалочка', 2);

-- --------------------------------------------------------

--
-- Структура таблицы `posts`
--

CREATE TABLE `posts` (
  `id` int NOT NULL,
  `name_post` varchar(100) NOT NULL,
  `img` mediumtext NOT NULL,
  `text_post` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `posts`
--

INSERT INTO `posts` (`id`, `name_post`, `img`, `text_post`) VALUES
(1, 'Последние участники k-pop коллектива BTS ушли в армию\r\n', 'https://sun9-49.userapi.com/impg/2fqe7nSAfLEgMp8cFNC3FhJ5PAqXhWcj87Ey4Q/PXAYb1sysIU.jpg?size=2048x1327&quality=95&sign=e2e2783a057f4c3654e97fb957baa351&type=album', 'Группа BTS объявила, что их участники RM, Чимин, Тэхен и Чонгук в середине декабря вступят в армию и будут служить в пехотной части.\r\nСогласно эксклюзивному репортажу Star News от 29 ноября, RM и Тэхен начнут службу в тыловой военной части 11 декабря. Затем, на следующий день, 12 декабря, Чимин и Чонгук также пройдут военное обучение в боевой части.После завершения тренировок RM, Чимин, Тэхен и Чонгук будут служить в армии в качестве призывников в течение 18 месяцев.\r\nКомпания Big Hit Music объявила 22 ноября через платформу сообщества поклонников Weverse: \"Хотим сообщить всем нашим дорогим фанатам, всегда любившим и ценившим BTS, что RM, Чимин, Тэхен и Чонгук начали процедуры по выполнению воинской обязанности. Они находятся в стадии подготовки к армейской службе. Будем информировать вас о последующих новостях о призыве, как только они будут подтверждены.\"\r\nBig Hit Music также добавили: \"Мы просим вас поддерживать RM, Чимина, Тэхена и Чонгука теплыми словами и бесконечной любовью до их возвращения после выполнения воинской обязанности. Мы также обещаем продолжить оказывать поддержку и любовь нашим артистам.\"\r\nТем временем, участники BTS - Джин, Хосок и Шуга - также исполняют военную обязанность. Джин планирует закончить службу в июне следующего года, Хосок был призван в армию в апреле этого года, а Шуга выполняет социальную гражданскую службу с сентября.\r\nЗапланированные возвращения Бантан со службы:\r\nДжин - 12 июня 2024\r\nХосок - 17 октября 2024\r\nЮнги - 21 июня 2025\r\nНамджун, Тэхен, Чимин, Чонгук - 10-11 июня 2025\r\nЮнги вернется позже, так как проходит альтернативную службу, которая длится на несколько месяцев дольше обычной.'),
(2, 'Шуга из BTS объявил даты и города первого сольного тура\r\n', 'https://avatars.mds.yandex.net/i?id=b4e497acedb9c02bc4106dc79f77ba4582800372-10876343-images-thumbs&n=13\r\n', 'Шуга из BTS отправится в первый сольный тур.\r\n\r\n15 февраля в 00:00 KST Шуга объявил расписание первого сольного тура под псевдонимом Agust D.\r\n\r\nСмотрите также: Слухи об отношениях Чонгука из BTS и Ли Ю Би: «Встречались до мая прошлого года… Подарил ей сумку Chanel»\r\n\r\nТур Шуги начнется в США, где он выступит в Бельмонт Парк 26 и 27 апреля, в Ньюарке 27 апреля, Роузмонте 3, 5 и 6 мая, Лос-Анджелесе 10, 11 и 14 мая и Окленде 16 и 17 мая.\r\n\r\nАртист вернется в Азию и выступит в Джакарте с 26 по 28 мая, Бангкоке 10 и 11 июня и Сингапуре 17 и 18 июня. 24 и 25 июня Шуга проведет концерты на стадионе Джамсиль в Сеуле.\r\n\r\nПозже Шуга опубликует информацию об остановках в Японии.'),
(3, 'Ви (Ким Тэхён) из группы BTS начинает интенсивную подготовку в Школе общей администрации армии', 'https://kpopstarz.ru/wp-content/uploads/2024/01/1705713791-cover-7-758x457.png\r\n', 'Ви из BTS приступает к следующему этапу обучения в армии.\r\n\r\n16 января Тхэхён завершил пятинедельную базовую подготовку, поступив 11 декабря в учебный центр Нонсан. Благодаря своей исключительной успеваемости, он был удостоен чести стать одним из шести элитных учеников из двухсот новобранцев.\r\n18 января Тхэхён был замечен на поезде, идущем к мосту Чонхэнгё, чтобы поступить в Школу общей администрации армии.\r\n\r\nОн был одет с ног до головы в военную форму, на плече у него висел черный рюкзак, а в руках он держал еще одну большую военную сумку.\r\nПоскольку Тхэхён решил вступить в контртеррористическое подразделение, Специальную оперативную группу Командования обороны столицы (она же Специальная дежурная группа), ему предстоит пройти дополнительную трехнедельную подготовку в Школе общей администрации армии перед отправкой в свое подразделение.\r\n\r\nНовый учебный центр находится в самом лучшем состоянии, оснащен отличным оборудованием и очень просторен.\r\nОбщевойсковая школа управления – одно из лучших учебных заведений для подготовки военных специалистов, обладающих не только исключительными боевыми навыками, но и сильными лидерскими качествами.\r\n\r\nЧеловек, служивший в прошлом году в Специальной группе, рассказал в своем блоге, что специализированная подготовка SDT известна своей высокой сложностью, и некоторые слушатели находят ее настолько трудной, что уходят из армии.\r\n\r\nФизические тренировки длятся до поздней ночи, что повышает общую интенсивность обучения.\r\n\r\nПеред тем как Тхэхён покинул армейский учебный центр Нонсан, его корейские поклонники установили баннеры вдоль маршрута к его новому тренировочному лагерю.\r\nНа баннерах были написаны поздравления Тхэхёну и его подразделению с окончанием базовой подготовки, а также теплые слова любви, например, “Ким Тэхён, мы клянемся тебе в верности на всю жизнь”.'),
(4, 'IU делится личными фотографиями со съемок клипа “Love Wins All” с Ви BTS', 'https://kpopstarz.ru/wp-content/uploads/2024/01/1706203214-untitled-11-758x474.jpg\r\n', 'IU представила поклонникам эксклюзивный закадровый взгляд на свое музыкальное видео “Love Wins All” с участием Ви из BTS.\r\n\r\nСингл IU “Love Wins All”, который вышел 24 января KST, покорил сердца многих своим захватывающим музыкальным видео.\r\n\r\nМузыкальное видео “Love Wins All” получило широкое признание и множество похвал за кинематографичность.\r\n\r\n25 января IU поделилась новыми закулисными снимками в своих социальных сетях с подписью: “Любовь побеждает все. Спасибо вам всем”.\r\nКорейские нетизены отметили: “Они такие милые”, “Они такие хорошенькие”, “Мне очень понравилась их совместная химия в клипе”, “Можете выложить больше фотографий?”. “Такие красивые и симпатичные”, “Их улыбки вместе выглядят так мило”, “Свадебное платье и прическа в моем вкусе”, “Их химия просто сумасшедшая” и “Они так мило смотрятся вместе”.\r\n27 января Big Hit Entertainment представили закулисные фотографии Ви в сотрудничестве совместного проекта с IU. Когда две музыкальные звезды объединяются, это вызывает восторг у поклонников. Фотографии привлекли большое внимание: от восхищения химией IU и Ви до обсуждения концепции и звучания этого проекта.');

-- --------------------------------------------------------

--
-- Структура таблицы `prodagi dish`
--

CREATE TABLE `prodagi dish` (
  `id prodagi dish` int NOT NULL,
  `id chek` int NOT NULL,
  `id dish` int NOT NULL,
  `col prod dish` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `prodagi dish`
--

INSERT INTO `prodagi dish` (`id prodagi dish`, `id chek`, `id dish`, `col prod dish`) VALUES
(1, 1, 2, 1),
(2, 2, 1, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `Prodagi dop uslug`
--

CREATE TABLE `Prodagi dop uslug` (
  `id prodag uslug` int NOT NULL,
  `id dop uslug` int NOT NULL,
  `id chek` int NOT NULL,
  `col-vo prodag` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `Prodagi dop uslug`
--

INSERT INTO `Prodagi dop uslug` (`id prodag uslug`, `id dop uslug`, `id chek`, `col-vo prodag`) VALUES
(1, 3, 1, 1),
(2, 1, 2, 1),
(3, 3, 1, 1),
(4, 1, 2, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `product`
--

CREATE TABLE `product` (
  `id product` int NOT NULL,
  `name product` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `product`
--

INSERT INTO `product` (`id product`, `name product`) VALUES
(1, 'Огурец'),
(2, 'Молоко');

-- --------------------------------------------------------

--
-- Структура таблицы `role`
--

CREATE TABLE `role` (
  `id` int NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `role`
--

INSERT INTO `role` (`id`, `name`) VALUES
(1, 'user'),
(2, 'admin');

-- --------------------------------------------------------

--
-- Структура таблицы `sostav`
--

CREATE TABLE `sostav` (
  `id sostav` int NOT NULL,
  `id product` int NOT NULL,
  `id dish` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `sostav`
--

INSERT INTO `sostav` (`id sostav`, `id product`, `id dish`) VALUES
(1, 1, 1),
(3, 2, 4);

-- --------------------------------------------------------

--
-- Структура таблицы `spisok dish`
--

CREATE TABLE `spisok dish` (
  `id dish` int NOT NULL,
  `name dish` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `spisok dish`
--

INSERT INTO `spisok dish` (`id dish`, `name dish`) VALUES
(1, 'Коктейль из огурца'),
(2, 'Салат из молока'),
(3, 'Коктейль из огурца'),
(4, 'Салат из молока');

-- --------------------------------------------------------

--
-- Структура таблицы `status`
--

CREATE TABLE `status` (
  `id` int NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `status`
--

INSERT INTO `status` (`id`, `status`) VALUES
(1, 'Одобрен'),
(2, 'Не одобрен'),
(3, 'Новый');

-- --------------------------------------------------------

--
-- Структура таблицы `status_user`
--

CREATE TABLE `status_user` (
  `id` int NOT NULL,
  `name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `status_user`
--

INSERT INTO `status_user` (`id`, `name`) VALUES
(1, 'admin'),
(2, 'user');

-- --------------------------------------------------------

--
-- Структура таблицы `status_users`
--

CREATE TABLE `status_users` (
  `id` int NOT NULL,
  `name_status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `status_users`
--

INSERT INTO `status_users` (`id`, `name_status`) VALUES
(1, 'admin'),
(2, 'user');

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `id` int NOT NULL,
  `login` varchar(20) NOT NULL,
  `password` int NOT NULL,
  `name` varchar(40) NOT NULL,
  `surname` varchar(40) NOT NULL,
  `status_user_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id`, `login`, `password`, `name`, `surname`, `status_user_id`) VALUES
(1, 'user', 12345, 'Алена', 'Никифорова', 0),
(2, 'admin', 123, 'Аленка', 'Никифорова', 0),
(3, 'nikol', 1234, 'Варвара', 'Никифорова', 0),
(4, 'aleshka', 555, 'Алешка', 'пкрарр', 0),
(5, 'aleshka', 555, 'Алешка', 'ловариапрпр', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `name` varchar(50) NOT NULL,
  `login` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `login`, `password`) VALUES
(1, 'Alena', 'niki_2005', 'Allena'),
(2, 'Ma', 'mash_mash', '123'),
(6, 'rfgdg', 'dgd', 'dfrg');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id_art`);

--
-- Индексы таблицы `blog_users`
--
ALTER TABLE `blog_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status` (`id_status_users`),
  ADD KEY `status_users` (`id_status_users`),
  ADD KEY `id_status_users` (`id_status_users`);

--
-- Индексы таблицы `catalog`
--
ALTER TABLE `catalog`
  ADD PRIMARY KEY (`id_company`);

--
-- Индексы таблицы `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `chek`
--
ALTER TABLE `chek`
  ADD PRIMARY KEY (`id chek`);

--
-- Индексы таблицы `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id client`),
  ADD KEY `id menu` (`id menu`,`id chek`),
  ADD KEY `id chek` (`id chek`);

--
-- Индексы таблицы `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_blog_users` (`id_blog_users`,`id_status`),
  ADD KEY `id_status` (`id_status`),
  ADD KEY `id_post` (`id_posts`),
  ADD KEY `id_posts` (`id_posts`);

--
-- Индексы таблицы `Dop uslugi`
--
ALTER TABLE `Dop uslugi`
  ADD PRIMARY KEY (`id dop uslugi`);

--
-- Индексы таблицы `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id menu`),
  ADD KEY `id dish` (`id dish`);

--
-- Индексы таблицы `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`id_notes`),
  ADD KEY `id_category` (`id_category`);

--
-- Индексы таблицы `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `prodagi dish`
--
ALTER TABLE `prodagi dish`
  ADD PRIMARY KEY (`id prodagi dish`),
  ADD KEY `id chek` (`id chek`),
  ADD KEY `id dish` (`id dish`);

--
-- Индексы таблицы `Prodagi dop uslug`
--
ALTER TABLE `Prodagi dop uslug`
  ADD PRIMARY KEY (`id prodag uslug`),
  ADD KEY `id dop uslug` (`id dop uslug`,`id chek`),
  ADD KEY `id chek` (`id chek`);

--
-- Индексы таблицы `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id product`);

--
-- Индексы таблицы `sostav`
--
ALTER TABLE `sostav`
  ADD PRIMARY KEY (`id sostav`),
  ADD KEY `id product` (`id product`,`id dish`),
  ADD KEY `id dish` (`id dish`);

--
-- Индексы таблицы `spisok dish`
--
ALTER TABLE `spisok dish`
  ADD PRIMARY KEY (`id dish`);

--
-- Индексы таблицы `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `status_users`
--
ALTER TABLE `status_users`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status user_id` (`status_user_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `articles`
--
ALTER TABLE `articles`
  MODIFY `id_art` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `blog_users`
--
ALTER TABLE `blog_users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `catalog`
--
ALTER TABLE `catalog`
  MODIFY `id_company` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `category`
--
ALTER TABLE `category`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `chek`
--
ALTER TABLE `chek`
  MODIFY `id chek` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `client`
--
ALTER TABLE `client`
  MODIFY `id client` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT для таблицы `Dop uslugi`
--
ALTER TABLE `Dop uslugi`
  MODIFY `id dop uslugi` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `menu`
--
ALTER TABLE `menu`
  MODIFY `id menu` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `notes`
--
ALTER TABLE `notes`
  MODIFY `id_notes` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT для таблицы `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `prodagi dish`
--
ALTER TABLE `prodagi dish`
  MODIFY `id prodagi dish` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `Prodagi dop uslug`
--
ALTER TABLE `Prodagi dop uslug`
  MODIFY `id prodag uslug` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `product`
--
ALTER TABLE `product`
  MODIFY `id product` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `sostav`
--
ALTER TABLE `sostav`
  MODIFY `id sostav` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `spisok dish`
--
ALTER TABLE `spisok dish`
  MODIFY `id dish` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `status`
--
ALTER TABLE `status`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `status_users`
--
ALTER TABLE `status_users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `blog_users`
--
ALTER TABLE `blog_users`
  ADD CONSTRAINT `blog_users_ibfk_1` FOREIGN KEY (`id_status_users`) REFERENCES `status_users` (`id`);

--
-- Ограничения внешнего ключа таблицы `client`
--
ALTER TABLE `client`
  ADD CONSTRAINT `client_ibfk_1` FOREIGN KEY (`id chek`) REFERENCES `chek` (`id chek`),
  ADD CONSTRAINT `client_ibfk_2` FOREIGN KEY (`id menu`) REFERENCES `menu` (`id menu`);

--
-- Ограничения внешнего ключа таблицы `comment`
--
ALTER TABLE `comment`
  ADD CONSTRAINT `comment_ibfk_1` FOREIGN KEY (`id_status`) REFERENCES `status` (`id`),
  ADD CONSTRAINT `comment_ibfk_2` FOREIGN KEY (`id_blog_users`) REFERENCES `blog_users` (`id`),
  ADD CONSTRAINT `comment_ibfk_3` FOREIGN KEY (`id_posts`) REFERENCES `posts` (`id`);

--
-- Ограничения внешнего ключа таблицы `menu`
--
ALTER TABLE `menu`
  ADD CONSTRAINT `menu_ibfk_1` FOREIGN KEY (`id dish`) REFERENCES `spisok dish` (`id dish`);

--
-- Ограничения внешнего ключа таблицы `notes`
--
ALTER TABLE `notes`
  ADD CONSTRAINT `notes_ibfk_1` FOREIGN KEY (`id_category`) REFERENCES `category` (`id`);

--
-- Ограничения внешнего ключа таблицы `prodagi dish`
--
ALTER TABLE `prodagi dish`
  ADD CONSTRAINT `prodagi dish_ibfk_1` FOREIGN KEY (`id chek`) REFERENCES `chek` (`id chek`),
  ADD CONSTRAINT `prodagi dish_ibfk_2` FOREIGN KEY (`id dish`) REFERENCES `spisok dish` (`id dish`);

--
-- Ограничения внешнего ключа таблицы `Prodagi dop uslug`
--
ALTER TABLE `Prodagi dop uslug`
  ADD CONSTRAINT `prodagi dop uslug_ibfk_1` FOREIGN KEY (`id dop uslug`) REFERENCES `Dop uslugi` (`id dop uslugi`),
  ADD CONSTRAINT `prodagi dop uslug_ibfk_2` FOREIGN KEY (`id chek`) REFERENCES `chek` (`id chek`);

--
-- Ограничения внешнего ключа таблицы `sostav`
--
ALTER TABLE `sostav`
  ADD CONSTRAINT `sostav_ibfk_1` FOREIGN KEY (`id product`) REFERENCES `product` (`id product`),
  ADD CONSTRAINT `sostav_ibfk_2` FOREIGN KEY (`id dish`) REFERENCES `spisok dish` (`id dish`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
