<?php
    include "pages/header.php";
    ?>
<?php
session_start();
$_SESSION['auth'] = null;
$_SESSION['id'] = null;
$_SESSION['status'] = 'user';
?>
<?php
    include "pages/footer.php";
    ?>