<?php
$num=$_GET['num'];
if($num%2==0 and $num%10==0 )
echo 'число четное и кратное 10';
elseif($num%2==0)
echo 'число только четное';
elseif($num%10==0)
echo 'число только кратное 10';
elseif($num%2!=0 and $num%10!=0)
echo 'число нечетное и не кратное 10';
else
echo 'некорректный ввод';
?>