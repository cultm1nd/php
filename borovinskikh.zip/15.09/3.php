<?php
$year=$_GET['year'];
if($year%400==0 and $year%100!=0 and $year%4==0 )
echo 'високосный';
else
echo 'не високосный';
?>