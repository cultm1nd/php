<?php
    $day=$_GET['num'];
    if($day>=1 and $day<=10)
    echo 'первая декада';
    elseif($day>=11 and $day<=20)
    echo 'вторая декада';
    elseif($day>=21 and $day<=31)
    echo 'третья декада';
    else
    echo 'некорректный ввод';
    ?>