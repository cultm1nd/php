<?php
$month=$_GET['month'];
if($month>=3 and $month<=5)
echo 'весна';
elseif($month>=6 and $month<=8)
echo 'лето';
elseif($month>=9 and $month<=11)
echo 'осень';
elseif($month=1 and $month=2  and $month=12)
echo 'зима';
else
echo 'некорректный ввод';
?>