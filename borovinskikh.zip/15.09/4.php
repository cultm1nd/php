<?php
$x=$_GET['x'];
$y=$_GET['y'];
$z=$_GET['z'];
$max=$x;
if($y>$max)
{
    $max=$y;
}
if($z>$max)
{
    $max=$z;
}
echo 'max= '.$max;
?>