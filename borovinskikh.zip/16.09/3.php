<?php
$day=1;
$age=1;
$gift=1;
while($gift<=100)
{
    $gift*=2;
    $gift+=$age;
    $age++;
    $day++;
}
echo 'подарок превысит 100$ на '.$day.'-й день рождения'
?>