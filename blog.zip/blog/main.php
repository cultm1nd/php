<!DOCTYPE html>
<html>
<head>
  <title>myBlog</title>
</head>
<link rel="stylesheet" href="style.css">
<body>
  <div class="header">
<div id="logo">
<img src="./img/logo.png">
</div>
<div id="forms">
<input type="button" id="vhod" value="вход">
<input type="button" id="reg" value="регистрация">
<input type="button" id="exit" value="выход">
</div>
  </div>
  <div class="posts">
    <div id="first">
    
    </div>
    <div id="second">
        
    </div>
    <div id="third">
        
    </div>
    <div id="four">
        
    </div>
  </div>
  <div class="footer">
    
  </div>
</body>
</html>
<?php

?>